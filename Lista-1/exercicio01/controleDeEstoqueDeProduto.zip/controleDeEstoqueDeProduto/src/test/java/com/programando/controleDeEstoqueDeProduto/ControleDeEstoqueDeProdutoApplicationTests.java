package com.programando.controleDeEstoqueDeProduto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeEstoqueDeProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
