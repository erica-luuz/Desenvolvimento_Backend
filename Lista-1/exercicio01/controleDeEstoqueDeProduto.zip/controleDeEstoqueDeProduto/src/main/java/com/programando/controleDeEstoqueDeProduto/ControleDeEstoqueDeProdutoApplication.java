package com.programando.controleDeEstoqueDeProduto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleDeEstoqueDeProdutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleDeEstoqueDeProdutoApplication.class, args);
	}

}
