package com.programando.controleDeEstoqueDeProdutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleDeEstoqueDeProdutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleDeEstoqueDeProdutosApplication.class, args);
	}

}
