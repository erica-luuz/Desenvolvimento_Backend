package com.programando.controleDeEstoqueDeProdutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeEstoqueDeProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
