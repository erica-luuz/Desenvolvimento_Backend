package com.programando.apiViaCep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiViaCepApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiViaCepApplication.class, args);
	}

}
